package net.kdt.pojavlaunch.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Modelo de estimativa de desempenho (sem dependencias do Android, facil de testar).
 * IMPORTANTE: os numeros sao ESTIMATIVAS heuristicas, nao medicoes reais.
 */
public final class PerformanceModel {
    private PerformanceModel() {}

    public enum Verdict { RUNS_WELL, RUNS_OK, LAGGY, RISK, WONT_OPEN, UNPLAYABLE }
    public enum Bottleneck { CPU, GPU, RAM }

    public static final class Device {
        public int cores = 4;
        public int bigCores = 2;
        public double bigGhz = 2.0;
        public double cpuMul = 0.75;
        public double gpuMul = 1.0;
        public boolean socKnown = false;
        public int ramMb = 4096;
        public int freeRamMb = 2048;
        public boolean is64Bit = true;
        public int screenW = 2400;
        public int screenH = 1080;
        public float resScale = 1f;
        public String socName = "";
    }

    public static final class Workload {
        public String mcVersion = "";
        public String loader = "unknown";
        public int modCount = 0;
        public int perfModCount = 0;
        public boolean hasShaderPack = false;
        public int renderDistance = 0; // 0 = desconhecido
        public int allocMb = 1024;
    }

    public static final class Result {
        public Verdict verdict = Verdict.RUNS_OK;
        public Bottleneck bottleneck = Bottleneck.CPU;
        public int fpsLow, fpsHigh;
        public int ramNeededMb, ramRecommendedMb, ramMaxSafeMb;
        public int suggestedRenderDistance; // 0 = sem sugestao
        public int suggestedResPercent;     // 0 = sem sugestao
        public int minorVersion;
        public boolean lowConfidence;
        public final List<String> warnings = new ArrayList<>();
        public final List<String> tips = new ArrayList<>();
    }

    private static final Pattern MC_VERSION = Pattern.compile("(?<![0-9.])1\\.(\\d{1,2})(?![0-9])");
    private static final Pattern NEOFORGE = Pattern.compile("neoforge-(\\d{2})\\.");
    private static final Pattern SNAPSHOT = Pattern.compile("(?<![0-9])(\\d{2})w\\d{2}[a-z]");

    public static int parseMinor(String v) {
        if (v == null || v.isEmpty()) return 20;
        String s = v.toLowerCase(Locale.ROOT);
        if (s.startsWith("latest")) return 21;
        if (s.matches("^[abc]\\d.*") || s.startsWith("rd-") || s.startsWith("inf-")) return 3;
        Matcher m = MC_VERSION.matcher(s);
        if (m.find()) return Integer.parseInt(m.group(1));
        Matcher neo = NEOFORGE.matcher(s);
        if (neo.find()) return Integer.parseInt(neo.group(1));
        Matcher sn = SNAPSHOT.matcher(s);
        if (sn.find()) {
            int yy = Integer.parseInt(sn.group(1));
            if (yy >= 24) return 21;
            if (yy == 23) return 20;
            if (yy == 22) return 19;
            if (yy == 21) return 17;
            if (yy == 20) return 16;
            if (yy == 19) return 14;
            return 13;
        }
        return 20;
    }

    static double versionLoad(int minor) {
        if (minor <= 8) return 0.55;
        if (minor <= 12) return 0.70;
        if (minor <= 16) return 0.95;
        if (minor <= 19) return 1.15;
        if (minor == 20) return 1.30;
        return 1.40;
    }

    static int baseRamMb(int minor) {
        if (minor <= 12) return 700;
        if (minor <= 16) return 1000;
        if (minor <= 19) return 1400;
        if (minor == 20) return 1700;
        return 1900;
    }

    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }
    private static int roundUp(int v, int step) { return ((v + step - 1) / step) * step; }
    private static int roundDown(int v, int step) { return (v / step) * step; }
    private static int round5(double v) { return Math.max(1, (int) (Math.round(v / 5.0) * 5)); }

    public static Result evaluate(Device d, Workload w) {
        Result r = new Result();
        int minor = parseMinor(w.mcVersion);
        r.minorVersion = minor;
        r.lowConfidence = !d.socKnown;

        double verLoad = versionLoad(minor);
        int mods = Math.max(0, w.modCount);
        double modLoad = 1.0 + Math.min(mods * 0.010, 3.0);
        double perfBoost = 1.0 - Math.min(w.perfModCount * 0.07, 0.38);
        int rd = w.renderDistance > 0 ? w.renderDistance : 8;
        double distLoad = clamp(Math.pow(rd / 8.0, 1.4), 0.35, 8.0);

        // ---- RAM ----
        int need = baseRamMb(minor) + mods * 24 + Math.max(0, rd - 8) * 40;
        if (w.hasShaderPack) need += 300;
        r.ramNeededMb = roundUp(need, 128);
        int safeMax = (int) (d.ramMb * (d.is64Bit ? 0.62 : 0.40));
        if (!d.is64Bit) safeMax = Math.min(safeMax, 1400);
        safeMax = Math.max(256, roundDown(safeMax, 128));
        r.ramMaxSafeMb = safeMax;
        int rec = roundUp((int) (r.ramNeededMb * 1.15), 128);
        r.ramRecommendedMb = Math.min(rec, safeMax);

        // ---- CPU ----
        double cpuIndex = d.bigGhz * d.cpuMul * (1.0 + 0.05 * Math.min(d.bigCores, 5));
        double load = verLoad * modLoad * distLoad * perfBoost;
        double fpsCpu = 22.0 * cpuIndex / load;

        // ---- GPU ----
        double px = (d.screenW * (double) d.screenH * d.resScale * d.resScale) / (1080.0 * 2400.0);
        px = Math.max(px, 0.15);
        double shader = w.hasShaderPack ? 2.6 : 1.0;
        double gpuLoad = (0.5 + 0.5 * verLoad) * px * shader * (0.7 + 0.3 * distLoad) * (0.85 + 0.15 * perfBoost);
        double fpsGpu = 70.0 * d.gpuMul / gpuLoad;

        double fps = Math.pow(Math.pow(fpsCpu, -3) + Math.pow(fpsGpu, -3), -1.0 / 3.0);

        // ---- Penalidade por pouca RAM alocada ----
        double alloc = Math.max(256, w.allocMb);
        double ramRatio = alloc / r.ramNeededMb;
        if (ramRatio < 1.0) fps *= Math.max(0.25, ramRatio * ramRatio);
        fps = Math.min(fps, 240);

        r.fpsLow = round5(fps * 0.75);
        r.fpsHigh = round5(fps * 1.20);
        r.bottleneck = fpsCpu <= fpsGpu ? Bottleneck.CPU : Bottleneck.GPU;

        // ---- Veredito ----
        double needOverSafe = r.ramNeededMb / (double) safeMax;
        if (needOverSafe > 1.35) {
            r.verdict = Verdict.WONT_OPEN;
            r.bottleneck = Bottleneck.RAM;
            r.warnings.add("A RAM necessaria (~" + r.ramNeededMb + " MB) passa muito do que este aparelho consegue dar com seguranca (~" + safeMax + " MB).");
        } else if (ramRatio < 0.85 || alloc > d.ramMb * 0.80) {
            r.verdict = Verdict.RISK;
            r.bottleneck = Bottleneck.RAM;
            if (ramRatio < 0.85) {
                r.warnings.add("RAM alocada (" + (int) alloc + " MB) abaixo do necessario (~" + r.ramNeededMb + " MB): risco de travar ou fechar.");
                if (r.ramRecommendedMb >= r.ramNeededMb * 0.95) {
                    r.tips.add("Aumente a RAM alocada para " + r.ramRecommendedMb + " MB.");
                } else {
                    r.tips.add("O aparelho nao tem RAM sobrando para isso: use menos mods, uma versao mais leve ou distancia menor.");
                }
            } else {
                r.warnings.add("Alocar " + (int) alloc + " MB de " + d.ramMb + " MB pode fazer o Android fechar o jogo.");
                r.tips.add("Reduza a RAM alocada para no maximo " + safeMax + " MB.");
            }
        } else if (fps >= 55) {
            r.verdict = Verdict.RUNS_WELL;
        } else if (fps >= 30) {
            r.verdict = Verdict.RUNS_OK;
        } else if (fps >= 12) {
            r.verdict = Verdict.LAGGY;
        } else {
            r.verdict = Verdict.UNPLAYABLE;
        }

        if (needOverSafe > 1.0 && needOverSafe <= 1.35) {
            r.warnings.add("RAM justa para este conjunto: podem ocorrer travadas do coletor de lixo.");
        }
        if (alloc > safeMax * 1.1 && r.verdict != Verdict.RISK) {
            r.warnings.add("RAM alocada acima do limite seguro (~" + safeMax + " MB).");
        }
        if (d.freeRamMb > 0 && d.freeRamMb < Math.min(alloc, r.ramNeededMb) * 0.9) {
            r.warnings.add("Pouca RAM livre agora (" + d.freeRamMb + " MB): feche outros apps antes de jogar.");
        }
        if (!d.is64Bit && minor >= 17) {
            r.warnings.add("Aparelho de 32 bits: versoes 1.17+ costumam ser instaveis.");
        }

        // ---- Dicas de desempenho ----
        if (r.verdict != Verdict.WONT_OPEN && fps < 45) {
            if (r.bottleneck == Bottleneck.CPU) {
                double targetLoad = 22.0 * cpuIndex / 45.0;
                double distNeeded = targetLoad / (verLoad * modLoad * perfBoost);
                int rdS = (int) Math.round(8.0 * Math.pow(Math.max(distNeeded, 0.01), 1.0 / 1.4));
                if (rdS < rd && rdS >= 2) {
                    r.suggestedRenderDistance = rdS;
                    r.tips.add("Reduza a distancia de renderizacao de " + rd + " para " + rdS + " chunks para chegar perto de 45 FPS.");
                } else if (rdS < 2) {
                    r.tips.add("Mesmo com distancia minima o processador sofre: use uma versao mais antiga ou menos mods.");
                }
            } else {
                double px2 = (70.0 * d.gpuMul / 45.0) / ((0.5 + 0.5 * verLoad) * shader * (0.7 + 0.3 * distLoad) * (0.85 + 0.15 * perfBoost));
                double scale = Math.sqrt(Math.max(px2, 0.01) / ((d.screenW * (double) d.screenH) / (1080.0 * 2400.0)));
                int pct = (int) clamp(Math.round(scale * 100.0), 40, 100);
                if (pct < Math.round(d.resScale * 100f)) {
                    r.suggestedResPercent = pct;
                    r.tips.add("A GPU e o limite: reduza a escala de resolucao para ~" + pct + "%.");
                }
            }
            if (w.hasShaderPack) r.tips.add("Desative o shader pack: shaders costumam cortar o FPS pela metade ou mais.");
            if (w.perfModCount == 0 && minor >= 8) {
                if ("fabric".equals(w.loader) || "quilt".equals(w.loader)) {
                    r.tips.add("Instale Sodium, Lithium e ModernFix (Fabric) para ganhar FPS.");
                } else if ("forge".equals(w.loader) || "neoforge".equals(w.loader)) {
                    r.tips.add(minor >= 16
                            ? "Instale Embeddium, ModernFix e FerriteCore (Forge) para ganhar FPS e economizar RAM."
                            : "Instale mods de otimizacao compativeis (ex.: FoamFix/VanillaFix em 1.12) para ganhar FPS.");
                } else {
                    r.tips.add("Se for usar mods, Fabric + Sodium costuma dar bem mais FPS que o vanilla.");
                }
            }
        }
        if (d.cores >= 6 && r.verdict != Verdict.RUNS_WELL && r.verdict != Verdict.WONT_OPEN) {
            r.tips.add("Ative a afinidade de nucleos grandes nas configuracoes (o botao Otimizar faz isso).");
        }
        if (r.lowConfidence) {
            r.warnings.add("Processador nao reconhecido: estimativa menos precisa.");
        }
        return r;
    }
}
