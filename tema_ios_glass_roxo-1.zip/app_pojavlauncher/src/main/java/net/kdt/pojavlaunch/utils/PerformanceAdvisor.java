package net.kdt.pojavlaunch.utils;

import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import net.kdt.pojavlaunch.Architecture;
import net.kdt.pojavlaunch.R;
import net.kdt.pojavlaunch.Tools;
import net.kdt.pojavlaunch.instances.Instance;
import net.kdt.pojavlaunch.prefs.LauncherPreferences;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Le o aparelho e a instancia selecionada, calcula a estimativa (PerformanceModel)
 * e mostra o relatorio / aviso antes de jogar.
 */
public final class PerformanceAdvisor {
    private PerformanceAdvisor() {}

    /** {padrao, cpuMul, gpuMul}. Padrao terminado em * = prefixo; senao igual ao token. */
    private static final Object[][] SOC_TABLE = {
            // Qualcomm
            {"sm8750", 1.70, 4.4}, {"sun", 1.70, 4.4},
            {"sm8650", 1.50, 3.9}, {"pineapple", 1.50, 3.9},
            {"sm8550", 1.40, 3.6}, {"kalama", 1.40, 3.6},
            {"sm8475", 1.20, 3.0}, {"sm8450", 1.20, 3.0}, {"cape", 1.20, 3.0}, {"taro", 1.20, 3.0},
            {"sm8350", 1.10, 2.6}, {"lahaina", 1.10, 2.6},
            {"sm8250", 0.95, 2.2}, {"kona", 0.95, 2.2},
            {"sm8150", 0.85, 1.9}, {"msmnile", 0.85, 1.9},
            {"lito", 0.85, 1.6},
            {"sm7*", 0.95, 1.8},
            {"sm6*", 0.70, 1.0},
            {"sm4*", 0.55, 0.7},
            {"msm8998", 0.70, 1.2}, {"msm8996", 0.55, 1.0}, {"msm8*", 0.45, 0.6},
            // MediaTek
            {"mt6991", 1.60, 3.6}, {"mt6989", 1.50, 3.2}, {"mt6985", 1.35, 3.0}, {"mt6983", 1.25, 2.6},
            {"mt6897", 1.10, 2.2}, {"mt6895", 1.00, 2.0},
            {"mt6893", 0.90, 1.8}, {"mt6891", 0.90, 1.8},
            {"mt6879", 0.80, 1.4}, {"mt6877", 0.80, 1.4},
            {"mt6785", 0.65, 1.0}, {"mt6769", 0.60, 0.8}, {"mt6768", 0.60, 0.8},
            {"mt6765", 0.50, 0.5}, {"mt6762", 0.50, 0.5}, {"mt6761", 0.45, 0.4}, {"mt6739", 0.40, 0.4},
            // Samsung Exynos / Google Tensor
            {"s5e9945", 1.30, 3.0}, {"s5e9935", 1.20, 3.2}, {"s5e9925", 1.20, 3.0},
            {"exynos2100", 1.05, 2.4}, {"exynos990", 0.90, 2.0}, {"exynos9820", 0.80, 1.6},
            {"zumapro", 1.30, 2.8}, {"zuma", 1.20, 2.6}, {"gs201", 1.10, 2.2}, {"gs101", 1.00, 2.0},
            // Unisoc
            {"t610", 0.50, 0.5}, {"t618", 0.55, 0.6}, {"t606", 0.45, 0.4},
    };

    private static double[] socProfile(String key) {
        String[] tokens = key.toLowerCase(Locale.ROOT).split("[^a-z0-9]+");
        for (Object[] row : SOC_TABLE) {
            String pat = (String) row[0];
            boolean prefix = pat.endsWith("*");
            String p = prefix ? pat.substring(0, pat.length() - 1) : pat;
            for (String t : tokens) {
                if (t.isEmpty()) continue;
                if (prefix ? t.startsWith(p) : t.equals(p)) {
                    return new double[]{(Double) row[1], (Double) row[2]};
                }
            }
        }
        return null;
    }

    private static double readMaxFreqGhz(int cpu) {
        String[] paths = {
                "/sys/devices/system/cpu/cpu" + cpu + "/cpufreq/cpuinfo_max_freq",
                "/sys/devices/system/cpu/cpu" + cpu + "/cpufreq/scaling_max_freq"
        };
        for (String path : paths) {
            try (BufferedReader br = new BufferedReader(new FileReader(path))) {
                String line = br.readLine();
                if (line != null) {
                    long khz = Long.parseLong(line.trim());
                    if (khz > 0) return khz / 1000000.0;
                }
            } catch (Exception ignored) {}
        }
        return 0;
    }

    public static PerformanceModel.Device probeDevice(Context ctx) {
        PerformanceModel.Device d = new PerformanceModel.Device();
        d.cores = Math.max(1, Runtime.getRuntime().availableProcessors());
        d.ramMb = Tools.getTotalDeviceMemory(ctx);
        d.freeRamMb = Tools.getFreeDeviceMemory(ctx);
        d.is64Bit = Architecture.is64BitsDevice();
        DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
        d.screenW = Math.max(dm.widthPixels, dm.heightPixels);
        d.screenH = Math.min(dm.widthPixels, dm.heightPixels);
        d.resScale = LauncherPreferences.PREF_SCALE_FACTOR;

        StringBuilder sb = new StringBuilder();
        if (Build.VERSION.SDK_INT >= 31) {
            sb.append(Build.SOC_MANUFACTURER).append(' ').append(Build.SOC_MODEL).append(' ');
        }
        sb.append(Build.BOARD).append(' ').append(Build.HARDWARE);
        d.socName = sb.toString().trim();

        double[] prof = socProfile(d.socName);
        if (prof != null) {
            d.cpuMul = prof[0];
            d.gpuMul = prof[1];
            d.socKnown = true;
        } else {
            // Fallback pela idade do Android e pela RAM
            int sdk = Build.VERSION.SDK_INT;
            double base = sdk <= 28 ? 0.5 : sdk <= 30 ? 0.7 : sdk <= 32 ? 0.85 : sdk == 33 ? 1.0 : 1.15;
            if (d.ramMb < 3000) base *= 0.8; else if (d.ramMb >= 8000) base *= 1.1;
            String lower = d.socName.toLowerCase(Locale.ROOT);
            d.cpuMul = base;
            d.gpuMul = base * (lower.contains("mt") || lower.contains("exynos") || lower.contains("mali") ? 0.9 : 1.2);
        }

        double[] freqs = new double[d.cores];
        double max = 0;
        for (int i = 0; i < d.cores; i++) {
            freqs[i] = readMaxFreqGhz(i);
            max = Math.max(max, freqs[i]);
        }
        if (max > 0) {
            d.bigGhz = max;
            int big = 0;
            for (double f : freqs) if (f >= max * 0.75) big++;
            d.bigCores = Math.max(1, big);
        } else {
            d.bigGhz = Math.max(1.8, Math.min(3.4, 1.6 + 0.9 * d.cpuMul));
            d.bigCores = Math.max(1, d.cores / 2);
        }
        return d;
    }

    private static final String[] PERF_MODS = {
            "sodium", "rubidium", "embeddium", "lithium", "ferritecore", "modernfix", "entityculling",
            "immediatelyfast", "starlight", "c2me", "krypton", "phosphor", "optifine", "canary",
            "vanillafix", "foamfix", "moreculling", "dashloader", "smoothboot", "noisium", "scalablelux"
    };
    private static final String[] SHADER_MODS = {"iris", "oculus", "optifine", "optiforge"};

    private static void scanMods(File dir, int depth, int[] counts) {
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isDirectory()) {
                if (depth < 1) scanMods(f, depth + 1, counts);
                continue;
            }
            String n = f.getName().toLowerCase(Locale.ROOT);
            if (!n.endsWith(".jar") && !n.endsWith(".jar.disabled")) continue;
            if (n.endsWith(".disabled")) continue;
            counts[0]++;
            for (String p : PERF_MODS) if (n.contains(p)) { counts[1]++; break; }
            for (String s : SHADER_MODS) if (n.contains(s)) { counts[2] = 1; break; }
        }
    }

    private static final Pattern XMX = Pattern.compile("-Xmx(\\d+)([mMgG])");

    public static PerformanceModel.Workload probeWorkload(Context ctx, Instance inst) {
        PerformanceModel.Workload w = new PerformanceModel.Workload();
        w.mcVersion = inst.versionId == null ? "" : inst.versionId;
        String lower = w.mcVersion.toLowerCase(Locale.ROOT);
        if (lower.contains("neoforge")) w.loader = "neoforge";
        else if (lower.contains("forge")) w.loader = "forge";
        else if (lower.contains("fabric")) w.loader = "fabric";
        else if (lower.contains("quilt")) w.loader = "quilt";
        else w.loader = "vanilla";

        File gameDir = inst.getGameDirectory();
        int[] counts = new int[3]; // mods, perf mods, tem mod de shader
        scanMods(new File(gameDir, "mods"), 0, counts);
        w.modCount = counts[0];
        w.perfModCount = counts[1];
        File[] packs = new File(gameDir, "shaderpacks").listFiles();
        w.hasShaderPack = counts[2] == 1 && packs != null && packs.length > 0;
        if (w.modCount > 0 && "vanilla".equals(w.loader)) w.loader = "unknown";

        try (BufferedReader br = new BufferedReader(new FileReader(new File(gameDir, "options.txt")))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("renderDistance:")) {
                    w.renderDistance = Integer.parseInt(line.substring(15).trim());
                    break;
                }
            }
        } catch (Exception ignored) {}

        w.allocMb = LauncherPreferences.PREF_RAM_ALLOCATION;
        try {
            String args = inst.getLaunchArgs();
            if (args != null) {
                Matcher m = XMX.matcher(args);
                if (m.find()) {
                    int v = Integer.parseInt(m.group(1));
                    w.allocMb = Character.toLowerCase(m.group(2).charAt(0)) == 'g' ? v * 1024 : v;
                }
            }
        } catch (Exception ignored) {}
        return w;
    }

    public static PerformanceModel.Result analyze(Context ctx, Instance inst) {
        return PerformanceModel.evaluate(probeDevice(ctx), probeWorkload(ctx, inst));
    }

    /** Aplica so ajustes que ja existem nas configuracoes do launcher (reversiveis la). */
    public static String applyRecommended(Context ctx, PerformanceModel.Device d, PerformanceModel.Result r) {
        android.content.SharedPreferences.Editor e = LauncherPreferences.DEFAULT_PREF.edit();
        StringBuilder done = new StringBuilder();
        if (r.ramRecommendedMb > 0 && r.ramRecommendedMb != LauncherPreferences.PREF_RAM_ALLOCATION) {
            e.putInt("allocation", r.ramRecommendedMb);
            LauncherPreferences.PREF_RAM_ALLOCATION = r.ramRecommendedMb;
            done.append("RAM ").append(r.ramRecommendedMb).append(" MB; ");
        }
        if (r.suggestedResPercent > 0) {
            e.putInt("resolutionRatio", r.suggestedResPercent);
            LauncherPreferences.PREF_SCALE_FACTOR = r.suggestedResPercent / 100f;
            done.append("resolucao ").append(r.suggestedResPercent).append("%; ");
        }
        if (d.cores >= 6 && !LauncherPreferences.PREF_BIG_CORE_AFFINITY) {
            e.putBoolean("bigCoreAffinity", true);
            LauncherPreferences.PREF_BIG_CORE_AFFINITY = true;
            done.append("afinidade de nucleos grandes; ");
        }
        e.apply();
        return done.toString();
    }

    private static boolean hasChanges(PerformanceModel.Device d, PerformanceModel.Result r) {
        return (r.ramRecommendedMb > 0 && r.ramRecommendedMb != LauncherPreferences.PREF_RAM_ALLOCATION)
                || r.suggestedResPercent > 0
                || (d.cores >= 6 && !LauncherPreferences.PREF_BIG_CORE_AFFINITY);
    }

    // ------------------------------------------------------------------ UI

    private static String verdictTitle(PerformanceModel.Verdict v) {
        switch (v) {
            case RUNS_WELL: return "Deve rodar bem";
            case RUNS_OK: return "Deve rodar de forma jogavel";
            case LAGGY: return "Vai rodar com lag";
            case RISK: return "Pode travar ou fechar ao abrir";
            case WONT_OPEN: return "Provavelmente nao vai abrir neste aparelho";
            default: return "Abre, mas fica praticamente injogavel";
        }
    }

    private static int verdictColor(PerformanceModel.Verdict v) {
        switch (v) {
            case RUNS_WELL: return Color.parseColor("#2E9E5B");
            case RUNS_OK: return Color.parseColor("#6A9E2E");
            case LAGGY: return Color.parseColor("#C28A00");
            case RISK: return Color.parseColor("#D9731A");
            default: return Color.parseColor("#D13B3B");
        }
    }

    private static int dp(Context c, int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics());
    }

    private static TextView line(Context c, String text, int sp, int color, boolean bold, int topDp) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(c, topDp);
        t.setLayoutParams(lp);
        return t;
    }

    private static String fpsText(PerformanceModel.Result r) {
        if (r.verdict == PerformanceModel.Verdict.WONT_OPEN) return "FPS: nao se aplica (falta de memoria)";
        String range = r.fpsLow + " a " + r.fpsHigh + " FPS";
        return r.verdict == PerformanceModel.Verdict.RISK ? "Se abrir: ~" + range : "FPS estimado: ~" + range;
    }

    private static String bottleneckText(PerformanceModel.Bottleneck b) {
        switch (b) {
            case RAM: return "Limite principal: memoria (RAM)";
            case GPU: return "Limite principal: placa de video (GPU)";
            default: return "Limite principal: processador (CPU)";
        }
    }

    public static void showReport(Context ctx, Instance inst) {
        final PerformanceModel.Device d = probeDevice(ctx);
        final PerformanceModel.Workload w = probeWorkload(ctx, inst);
        final PerformanceModel.Result r = PerformanceModel.evaluate(d, w);
        int text = ctx.getResources().getColor(R.color.primary_text);
        int sub = ctx.getResources().getColor(R.color.secondary_text);

        LinearLayout col = new LinearLayout(ctx);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(ctx, 20);
        col.setPadding(pad, dp(ctx, 8), pad, dp(ctx, 8));

        col.addView(line(ctx, verdictTitle(r.verdict), 18, verdictColor(r.verdict), true, 0));
        col.addView(line(ctx, fpsText(r), 16, text, true, 6));
        col.addView(line(ctx, bottleneckText(r.bottleneck), 13, sub, false, 2));

        String rd = w.renderDistance > 0 ? w.renderDistance + " chunks" : "padrao (nao encontrado)";
        String details = "Versao: " + (w.mcVersion.isEmpty() ? "?" : w.mcVersion)
                + "\nMods: " + w.modCount + " (otimizacao: " + w.perfModCount + ")"
                + (w.hasShaderPack ? " + shaders" : "")
                + "\nDistancia de renderizacao: " + rd
                + "\nRAM alocada: " + w.allocMb + " MB  |  necessaria: ~" + r.ramNeededMb
                + " MB  |  recomendada: " + r.ramRecommendedMb + " MB"
                + "\nAparelho: " + d.cores + " nucleos (" + d.bigCores + " rapidos, ate "
                + String.format(Locale.US, "%.2f", d.bigGhz) + " GHz), " + d.ramMb + " MB de RAM"
                + (d.socName.isEmpty() ? "" : "\nChip: " + d.socName);
        col.addView(line(ctx, details, 12, sub, false, 14));

        for (String s : r.warnings) col.addView(line(ctx, "\u26A0 " + s, 13, Color.parseColor("#B45F06"), false, 8));
        for (String s : r.tips) col.addView(line(ctx, "\u2022 " + s, 13, text, false, 8));

        col.addView(line(ctx, "Isto e uma estimativa calculada pelas especificacoes do aparelho e do pacote, nao uma medicao. O FPS real pode variar para mais ou para menos.",
                11, sub, false, 14));

        ScrollView sv = new ScrollView(ctx);
        sv.addView(col);

        AlertDialog.Builder b = new AlertDialog.Builder(ctx)
                .setTitle("Analise de desempenho")
                .setView(sv)
                .setNegativeButton("Fechar", null);
        if (hasChanges(d, r)) {
            b.setPositiveButton("Otimizar", (dlg, which) -> {
                String done = applyRecommended(ctx, d, r);
                android.widget.Toast.makeText(ctx,
                        done.isEmpty() ? "Nada para ajustar." : "Aplicado: " + done,
                        android.widget.Toast.LENGTH_LONG).show();
            });
        }
        b.show();
    }

    /** Roda a verificacao antes de jogar; so interrompe se houver risco real. */
    public static void guard(Context ctx, Instance inst, Runnable go) {
        final PerformanceModel.Device d;
        final PerformanceModel.Result r;
        try {
            d = probeDevice(ctx);
            r = PerformanceModel.evaluate(d, probeWorkload(ctx, inst));
        } catch (Throwable t) {
            go.run();
            return;
        }
        if (r.verdict != PerformanceModel.Verdict.RISK && r.verdict != PerformanceModel.Verdict.WONT_OPEN) {
            go.run();
            return;
        }
        StringBuilder msg = new StringBuilder();
        for (String s : r.warnings) msg.append(s).append("\n\n");
        for (String s : r.tips) msg.append("\u2022 ").append(s).append("\n");
        AlertDialog.Builder b = new AlertDialog.Builder(ctx)
                .setTitle(verdictTitle(r.verdict))
                .setMessage(msg.toString().trim())
                .setNeutralButton("Jogar mesmo assim", (dlg, which) -> go.run())
                .setNegativeButton("Cancelar", null);
        if (r.verdict == PerformanceModel.Verdict.RISK && hasChanges(d, r)) {
            b.setPositiveButton("Otimizar e jogar", (dlg, which) -> {
                applyRecommended(ctx, d, r);
                go.run();
            });
        } else {
            b.setPositiveButton("Ver analise", (dlg, which) -> showReport(ctx, inst));
        }
        b.show();
    }
}
